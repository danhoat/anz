<p><?php _e('BackWPup is dropping support for WordPress versions less than 5.0. Please update WordPress to the latest version. Without an update, you will not receive any new features.', 'backwpup') ?></p>
<p><?php _e('<a href="https://backwpup.com/support/" target="_blank">Contact our support team here</a> if any questions remain.', 'backwpup') ?></p>
