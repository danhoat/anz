<?php # -*- coding: utf-8 -*-

namespace Inpsyde\BackWPup\Notice;

class Promoter {

	const OPTION_NAME = 'backwpup_notice_promoter';
}
