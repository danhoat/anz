<?php

namespace Inpsyde\BackWPup\Http\Client;

/**
 * Exception thrown by an HTTP client.
 */
interface ClientExceptionInterface
{
}
