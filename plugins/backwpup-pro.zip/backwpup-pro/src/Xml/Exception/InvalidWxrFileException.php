<?php

namespace Inpsyde\BackWPup\Xml\Exception;

class InvalidWxrFileException extends \RuntimeException
{
}
